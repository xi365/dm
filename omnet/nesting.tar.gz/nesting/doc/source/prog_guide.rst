Programmer's Guide
==================

TODO
