# Contributors
* [Ben Carabelli](https://www.ipvs.uni-stuttgart.de/abteilungen/vs/abteilung/mitarbeiter/Ben.Carabelli) (University of Stuttgart / IPVS)
* [Frank Dürr](https://www.ipvs.uni-stuttgart.de/abteilungen/vs/abteilung/mitarbeiter/frank.duerr) (University of Stuttgart / IPVS)
* [Jonathan Falk](https://www.ipvs.uni-stuttgart.de/abteilungen/vs/abteilung/mitarbeiter/Jonathan.Falk) (University of Stuttgart / IPVS)
* Robin Finkbeiner
* Alexander Glavackij
* [David Hellmanns](https://www.ipvs.uni-stuttgart.de/abteilungen/vs/abteilung/mitarbeiter/David.Hellmanns) (University of Stuttgart / IPVS)
* Urim Limani
* [Naresh Nayak](https://www.ipvs.uni-stuttgart.de/abteilungen/vs/abteilung/mitarbeiter/Naresh.Nayak) (University of Stuttgart / IPVS)
* Adriaan Nieß
* Patrick Schneefuss
* Nicklas Segedi
* Michel Weitbrecht
