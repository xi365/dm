#include <iostream>  
#include <openssl/rsa.h>
#include "openssl/pem.h"
#include <string.h>
#include <fstream> 
#include <ctime>
#include <chrono>
#define KEY_LENGTH  2048               // 密钥长度
#define KEY_BYTE 426

using namespace std;

void sha256(const std::string &srcStr, std::string &encodedStr)
{
	// 调用sha256哈希  
	unsigned char shaStr[33] = {0};
	SHA256((const unsigned char *)srcStr.c_str(), srcStr.length(), shaStr);
 
	// 哈希后的字符串  
	encodedStr = std::string((const char *)shaStr);
}



std::string rsa_pri_sign(const std::string data, const std::string pri_filename, const std::string sign_filename)
{
	char sSign[KEY_LENGTH/8+1];
	unsigned int nSignLen = KEY_LENGTH/8;
	std::string sData;
		
	sha256(data, sData);

	BIO* priin = BIO_new(BIO_s_file());
	if (priin == NULL){
		perror("unable to generate BIO*!");
		exit(0);
	}
	BIO_read_filename(priin, pri_filename.c_str());
	RSA* prirsa = PEM_read_bio_RSAPrivateKey(priin, NULL, NULL, NULL);
	
	BIO_free(priin);
	if (prirsa == NULL){
		perror("unable to read rsa_pribatekey!");
		exit(0);
	}


	int ret = 0;
	auto duration_since_epoch1 = std::chrono::system_clock::now().time_since_epoch(); // 从1970-01-01 00:00:00到当前时间点的时长
    auto SignStartTime = std::chrono::duration_cast<std::chrono::nanoseconds>(duration_since_epoch1).count(); // 将时长转换为微秒数
	for(int i=0;i<1000;i++)
	{
		ret = RSA_sign(NID_sha256, (unsigned char *)sData.c_str(), sData.length(), (unsigned char *)sSign, &nSignLen, prirsa);
	}
	auto duration_since_epoch2 = std::chrono::system_clock::now().time_since_epoch(); // 从1970-01-01 00:00:00到当前时间点的时长
	auto SignEndTime = std::chrono::duration_cast<std::chrono::nanoseconds>(duration_since_epoch2).count(); // 将时长转换为微秒数
	std::cout<<"RSAsignTime:\t"<<(SignEndTime-SignStartTime)/1000<<"\t认证长度"<<sData.length()<<endl;
	sSign[KEY_LENGTH/8]='\0';
	
	
	// std::cout << "RSA_sign() ret:" << ret << std::endl;
	std::cout <<"shaDatalength:"<<sData.length()<< "\tsignlength:" << nSignLen<<"\trsalebgth"<<RSA_size(prirsa) << std::endl;
	RSA_free(prirsa);

	std::string str;
	for (int i = 0; i < nSignLen; ++i)
    	{
		str = str+sSign[i];
    	}
	
	//std::cout << str << std::endl;


	return str;
}
std::string ecc_pri_sign(const std::string data, const std::string pri_filename, const std::string sign_filename)
{
	unsigned int nSignLen;
	std::string sData;

	sha256(data, sData);

	BIO* priin = BIO_new(BIO_s_file());
	if (priin == NULL){
		perror("unable to generate BIO*!");
		exit(0);
	}

	BIO_read_filename(priin, pri_filename.c_str());
	// RSA* prirsa = PEM_read_bio_RSAPrivateKey(priin, NULL, NULL, NULL);
	EC_KEY* priecc = PEM_read_bio_ECPrivateKey(priin, NULL, NULL, NULL);
	int len = ECDSA_size(priecc);
	char *sSign=(char*)malloc(len);
	BIO_free(priin);
	if (priecc == NULL){
		perror("unable to read ecc_pribatekey!");
		exit(0);
	}
	int ret = 0;
	auto duration_since_epoch1 = std::chrono::system_clock::now().time_since_epoch(); // 从1970-01-01 00:00:00到当前时间点的时长
    auto SignStartTime = std::chrono::duration_cast<std::chrono::nanoseconds>(duration_since_epoch1).count(); // 将时长转换为微秒数
	for(int i=0;i<1000;i++)
	{
		ret = ECDSA_sign(NID_sha256, (unsigned char *)sData.c_str(), sData.length(), (unsigned char *)sSign, &nSignLen,priecc);
	}
	auto duration_since_epoch2 = std::chrono::system_clock::now().time_since_epoch(); // 从1970-01-01 00:00:00到当前时间点的时长
	auto SignEndTime = std::chrono::duration_cast<std::chrono::nanoseconds>(duration_since_epoch2).count(); // 将时长转换为微秒数
	std::cout << (SignEndTime-SignStartTime)/1000<< std::endl;
	
	
	// sSign[nSignLen]='\0';
	EC_KEY_free(priecc);
	int refer_length = 64;//指定参照长度，不足则补到该长度
	std::string str;
	for (int i = 0; i < nSignLen; ++i)
	{
		str = str+sSign[i];
	}
	for (int i = nSignLen; i<refer_length;i++)
	{
		str+='\0';
	}
	// std::cout<<"sSingLen	"<<nSignLen<<"\tsData\t"<<sData.length()<<len<<str.length()<<endl;
	//std::cout << str << std::endl;
	return str;
}



char * Base64Encode(const char * input, int length, bool with_new_line)
{
	BIO * bmem = NULL;
	BIO * b64 = NULL;
	BUF_MEM * bptr = NULL;
 
	b64 = BIO_new(BIO_f_base64());
	if(!with_new_line) {
		BIO_set_flags(b64, BIO_FLAGS_BASE64_NO_NL);
	}
	bmem = BIO_new(BIO_s_mem());
	b64 = BIO_push(b64, bmem);
	BIO_write(b64, input, length);
	BIO_flush(b64);
	BIO_get_mem_ptr(b64, &bptr);
 
	char * buff = (char *)malloc(bptr->length + 1);
	memcpy(buff, bptr->data, bptr->length);
	buff[bptr->length] = 0;
 
	BIO_free_all(b64);
 
	return buff;
}



char * Base64Decode(char * input, int length, bool with_new_line)
{
	BIO * b64 = NULL;
	BIO * bmem = NULL;
	char * buffer = (char *)malloc(length);
	memset(buffer, 0, length);
 
	b64 = BIO_new(BIO_f_base64());
	if(!with_new_line) {
		BIO_set_flags(b64, BIO_FLAGS_BASE64_NO_NL);
	}
	bmem = BIO_new_mem_buf(input, length);
	bmem = BIO_push(b64, bmem);
	BIO_read(bmem, buffer, length);
 
	BIO_free_all(bmem);
 
	return buffer;
}



std::string getPubkeyBase64(std::string pub_filename,std::string en_codeType)
{
	size_t pub_len;
	char *pub_key = NULL;
	std::string pubkey;

	BIO* pubin = BIO_new(BIO_s_file());
	if (pubin == NULL){
		perror("unable to generate BIO*!");
		exit(0);
	}

	BIO_read_filename(pubin, pub_filename.c_str());
	BIO *pub = BIO_new(BIO_s_mem());
	if(en_codeType=="RSA")
	{
		RSA* pubrsa = PEM_read_bio_RSAPublicKey(pubin, NULL, NULL, NULL);
		if (pubrsa == NULL){
			perror("unable to read rsa_pubkey!");
			exit(0);
		}
		PEM_write_bio_RSAPublicKey(pub, pubrsa);
		pub_len = BIO_pending(pub);
		pub_key = (char *)malloc(pub_len + 1);
		BIO_read(pub, pub_key, pub_len);
		pub_key[pub_len] = '\0';
		pubkey = pub_key;
		RSA_free(pubrsa);
	}
	else if(en_codeType=="ECC")
	{
		EC_KEY* pubecc = PEM_read_bio_EC_PUBKEY(pubin,NULL, NULL, NULL);
		if (pubecc == NULL){
			perror("unable to read ecc_pubkey!");
			exit(0);
		}
		PEM_write_bio_EC_PUBKEY(pub, pubecc);
		pub_len = BIO_pending(pub);
		pub_key = (char *)malloc(pub_len + 1);
		BIO_read(pub, pub_key, pub_len);
		pub_key[pub_len] = '\0';
		pubkey = pub_key;
		EC_KEY_free(pubecc);
	}
	BIO_free(pubin);
	BIO_free_all(pub);
	free(pub_key);
	// std::cout<<"pubkeylength:"<<pubkey.length()<<"pubkey"<<pubkey<<endl;
	return pubkey;
}


int main(int argc, char* argv[])
{
	std::string data = argv[1];
	std::string pri_filename = argv[2];
	std::string sign_filename = argv[3];
	std::string pub_filename = argv[4];
	std::string en_decodetype = argv[5];
	std::string signedData;
	std::string pubkey;

	std::string sign;
	if(en_decodetype=="RSA")
	{
		// auto duration_since_epoch1 = std::chrono::system_clock::now().time_since_epoch(); // 从1970-01-01 00:00:00到当前时间点的时长
        // auto SignStartTime = std::chrono::duration_cast<std::chrono::nanoseconds>(duration_since_epoch1).count(); // 将时长转换为微秒数
		sign = rsa_pri_sign(data, pri_filename, sign_filename);
		// auto duration_since_epoch2 = std::chrono::system_clock::now().time_since_epoch(); // 从1970-01-01 00:00:00到当前时间点的时长
        // auto SignEndTime = std::chrono::duration_cast<std::chrono::nanoseconds>(duration_since_epoch2).count(); // 将时长转换为微秒数
        // std::cout<<"signTime"<<SignEndTime-SignStartTime<<endl;
		pubkey = getPubkeyBase64(pub_filename,en_decodetype);
		pubkey = pubkey.substr(31);//由于rsa与ecc publiccckey文件储存格式不同，所以头部和尾部长也不同
		pubkey = pubkey.substr(0, pubkey.length()-29);
		char* dec_output = Base64Decode((char *)pubkey.c_str(), pubkey.length(), true);
		int klength = 0;
		while(!((*(dec_output + klength) == NULL) && (*(dec_output + klength + 1) == NULL) \
			&& (*(dec_output + klength + 2) == NULL) && (*(dec_output + klength + 3) == NULL)))
		{
			klength++;
		}
		string decode_key;
		int i = 0;
		for (i=0;i<klength;i++){
			decode_key=decode_key+dec_output[i];
		}
		
		signedData = data+sign+decode_key;
		std::cout<<"decode_key_:"<<decode_key.length()<<"\tsign"<<sign.length()<<"\tdatalength"<<data.length()<<signedData.length()<<endl;
	}
	else if(en_decodetype=="ECC")
	{
		
		sign = ecc_pri_sign(data, pri_filename, sign_filename);
		pubkey = getPubkeyBase64(pub_filename,en_decodetype);
		pubkey = pubkey.substr(27);
		pubkey = pubkey.substr(0, pubkey.length()-26);
		signedData = data+sign+pubkey;
	}
	char* dec_output = Base64Decode((char *)pubkey.c_str(), pubkey.length(), true);
	int klength = 0;
	// while(!((*(dec_output + klength) == NULL) && (*(dec_output + klength + 1) == NULL) \
	// 	&& (*(dec_output + klength + 2) == NULL) && (*(dec_output + klength + 3) == NULL)))
	// {
	// 	klength++;
	// }
	// string decode_key;
	// int i = 0;
	// for (i=0;i<klength;i++){
	// 	decode_key=decode_key+dec_output[i];
	// }
	// // std::cout<<"decode_keylen"<<pubkey<<endl;
	
	// signedData = signedData+decode_key;
	// std::cout<<"signdlength"<<sign.length()<<"data"<<data.length()<<"decode_key"<<decode_key.length()<<endl;
	char* enc_output = Base64Encode(signedData.c_str(), signedData.length(), false);
	string encode_sign = enc_output;
	
	
	ofstream fout;
	fout.open(sign_filename.c_str(), ios::trunc); 
	if(!fout.is_open()){
		perror("unable to open file!");
		exit(0);
	}
	fout << encode_sign; 
	fout.close();
	

	return 0;
}
