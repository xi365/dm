#include <iostream>  
#include <cassert>
#include <string.h>  
#include <vector>  
#include "openssl/sha.h"  
#include "openssl/rsa.h"  
#include "openssl/pem.h"
#include <stdio.h>
#include <openssl/ec.h>
#include <openssl/ecdsa.h>
#include <openssl/objects.h>
#include <openssl/err.h>
#define KEY_LENGTH  2048	// 密钥长度

void generateKey(std::string strKey[2], std::string pubkey_file, std::string prikey_file,std::string en_decode)
{
	// 公私密钥对  
	size_t pri_len;
	size_t pub_len;
	char *pri_key = NULL;
	char *pub_key = NULL;
	BIO *pri = BIO_new(BIO_s_mem());
	BIO *pub = BIO_new(BIO_s_mem());
 	if(en_decode == "RSA"){
	// 生成密钥对  
		RSA *keypair = RSA_generate_key(KEY_LENGTH, RSA_3, NULL, NULL);
		PEM_write_bio_RSAPrivateKey(pri, keypair, NULL, NULL, 0, NULL, NULL);
		PEM_write_bio_RSAPublicKey(pub, keypair);
		RSA_free(keypair);

 	}
	else if(en_decode == "ECC"){
		EC_KEY *keypair;
		if(NULL == (keypair = EC_KEY_new_by_curve_name(NID_secp224r1)))
	 		std::cout << "genetate error" << std::endl;
		if(1 != EC_KEY_generate_key(keypair)) 
			std::cout << "genetate error" << std::endl;
		
		PEM_write_bio_EC_PUBKEY(pub,keypair);
		PEM_write_bio_ECPrivateKey(pri,keypair,NULL, NULL, 0, NULL, NULL);
		EC_KEY_free(keypair);
	}
	// 获取长度  
	pri_len = BIO_pending(pri);
	pub_len = BIO_pending(pub);
 
	// 密钥对读取到字符串  
	pri_key = (char *)malloc(pri_len + 1);
	pub_key = (char *)malloc(pub_len + 1);
 
	BIO_read(pri, pri_key, pri_len);
	BIO_read(pub, pub_key, pub_len);
 
	pri_key[pri_len] = '\0';
	pub_key[pub_len] = '\0';
 	
	// 存储密钥对  
	strKey[0] = pub_key;
	strKey[1] = pri_key;
 
	// 存储到磁盘（这种方式存储的是begin rsa public key/ begin rsa private key开头的）
	FILE *pubFile = fopen(pubkey_file.c_str(), "w");
	if (pubFile == NULL)
	{
		assert(false);
		return;
	}
	fputs(pub_key, pubFile);
	fclose(pubFile);
 
	FILE *priFile = fopen(prikey_file.c_str(), "w");
	if (priFile == NULL)
	{
		assert(false);
		return;
	}
	fputs(pri_key, priFile);
	fclose(priFile);
 
	// 内存释放
	BIO_free_all(pub);
	BIO_free_all(pri);
 
	free(pri_key);
	free(pub_key);
}

int main(int argc, const char *argv[])
{
	std::string pubkey_file = argv[0];
	std::string prikey_file = argv[1];
	std::string en_decodetype = argv[2];
	// 密钥
	//std::cout << "=== 加解密 ===" << std::endl;
	std::string key[2];
	generateKey(key, pubkey_file, prikey_file,en_decodetype);

/*
	std::cout << "公钥: " << std::endl;
	std::cout << key[0] << std::endl;
	std::cout << "私钥： " << std::endl;
	std::cout << key[1] << std::endl;
*/
	return 0;
}
