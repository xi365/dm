#include <iostream>  
#include <string.h>  
#include "openssl/rsa.h"  
#include "openssl/pem.h"
#include <fstream> 
#include <ctime>
#include <chrono>
#define KEY_LENGTH  2048	// 密钥长度
#define KEY_BYTE KEY_LENGTH/8
#define ENCRYPT_LENGTH KEY_BYTE-11

using namespace std;


// 公钥加密  
// RSA
std::string rsa_pub_encrypt(const std::string &clearText, const std::string &pubKey)
{
	std::string strRet;
	BIO* pubin = BIO_new(BIO_s_file());
    	if (pubin == NULL){
		perror("unable to generate BIO*!");
		exit(0);
	}
    	BIO_read_filename(pubin, pubKey.c_str());
//  std::cout<<pubKey<<endl;
    	RSA* pubrsa = PEM_read_bio_RSAPublicKey(pubin, NULL, NULL, NULL);
	if(pubrsa==NULL){
		perror("unable to read rsa_pubkey!");
		exit(0);
	}

	BIO_free(pubin);
    	
	int len = RSA_size(pubrsa);
	char *encryptedText = (char *)malloc(len + 1);
	memset(encryptedText, 0, len + 1);
 
	// 加密函数
	int ret = 0;
	// auto duration_since_epoch1 = std::chrono::system_clock::now().time_since_epoch(); // 从1970-01-01 00:00:00到当前时间点的时长
    // auto SignStartTime = std::chrono::duration_cast<std::chrono::nanoseconds>(duration_since_epoch1).count(); // 将时长转换为微秒数
	for(int i=0;i<1;i++)
	{
		ret = RSA_public_encrypt(clearText.length(), (const unsigned char*)clearText.c_str(), (unsigned char*)encryptedText, pubrsa, RSA_PKCS1_PADDING);
	}
	// auto duration_since_epoch2 = std::chrono::system_clock::now().time_since_epoch(); // 从1970-01-01 00:00:00到当前时间点的时长
	// auto SignEndTime = std::chrono::duration_cast<std::chrono::nanoseconds>(duration_since_epoch2).count(); // 将时长转换为微秒数
	// std::cout<<"RSAsignTime:\t"<<(SignEndTime-SignStartTime)/1000<<"\t加密长度"<<clearText.length()<<endl;
	
	if (ret >= 0)strRet = std::string(encryptedText, ret);
	// 释放内存
	free(encryptedText);
	RSA_free(pubrsa);
 
	return strRet;
}
// ECC
std::string ecc_pub_encrypt(const std::string &clearText, const std::string &pubKey)
{

	std::string strRet;
	unsigned int sig_len;
  	char*signature;
	BIO* pubin = BIO_new(BIO_s_file());
    	if (pubin == NULL){
		perror("unable to generate BIO*!");
		exit(0);
	}
    	BIO_read_filename(pubin, pubKey.c_str());
 
    	EC_KEY * pubecc = PEM_read_bio_EC_PUBKEY(pubin, NULL, NULL, NULL);
		// EC_KEY * pubecc = PEM_read_bio_ECPrivateKey(pubin, NULL, NULL, NULL);
		
	if(pubecc==NULL){
		perror("unable to read ecc_pubkey!");
		exit(0);
	}
 
    BIO_free(pubin);
    	
	int len = ECDSA_size(pubecc);
   	signature = (char*)malloc(len+1);
	memset(signature, 0, len+1);
 	
	// 加密函数
	int ret = ECDSA_sign(0, (const unsigned char*)clearText.c_str(),clearText.length(), (unsigned char*)signature, &sig_len,pubecc);

	// int ret=EVP_PKEY_encrypt(pubecc, (unsigned char*)signature, &sig_len,(unsigned char*)clearText.c_str(),&clearText.length() );
	if (ret >= 0)strRet = std::string(signature, ret);
 
 	// std::cout<<signature<<pubKey<<endl;
	// 释放内存
	free(signature);
	EC_KEY_free(pubecc);

	return strRet;
}
 
char * Base64Encode(const char * input, int length, bool with_new_line)
{
	BIO * bmem = NULL;
	BIO * b64 = NULL;
	BUF_MEM * bptr = NULL;
 
	b64 = BIO_new(BIO_f_base64());
	if(!with_new_line) {
		BIO_set_flags(b64, BIO_FLAGS_BASE64_NO_NL);
	}
	bmem = BIO_new(BIO_s_mem());
	b64 = BIO_push(b64, bmem);
	BIO_write(b64, input, length);
	BIO_flush(b64);
	BIO_get_mem_ptr(b64, &bptr);
 
	char * buff = (char *)malloc(bptr->length + 1);
	memcpy(buff, bptr->data, bptr->length);
	buff[bptr->length] = 0;
 
	BIO_free_all(b64);
 
	return buff;
}

char * Base64Decode(char * input, int length, bool with_new_line)
{
	BIO * b64 = NULL;
	BIO * bmem = NULL;
	char * buffer = (char *)malloc(length);
	memset(buffer, 0, length);
 
	b64 = BIO_new(BIO_f_base64());
	if(!with_new_line) {
		BIO_set_flags(b64, BIO_FLAGS_BASE64_NO_NL);
	}
	bmem = BIO_new_mem_buf(input, length);
	bmem = BIO_push(b64, bmem);
	BIO_read(bmem, buffer, length);
 
	BIO_free_all(bmem);
 
	return buffer;
}

int main(int argc, const char *argv[])
{
	std::string data = argv[0];

	std::string pub_filename = argv[1];
	std::string encrypt_filename = argv[2];
	std::string encoded = argv[3];
	std::string en_decodetype = argv[4];
	std::string encryptText="";
	if (strcmp(encoded.c_str(), "true")==0){
		char* dec_output = Base64Decode((char *)data.c_str(), data.length(), false);
		//char* dec_output = (char *)data.c_str();
		int clength = 0;
		while(!((*(dec_output + clength) == NULL) && (*(dec_output + clength + 1) == NULL) \
			&& (*(dec_output + clength + 2) == NULL) && (*(dec_output + clength + 3) == NULL)))
		{
			clength++;
		}
		int i = 0;
		string decode_data;

		for (i=0;i<clength;i++){
			decode_data=decode_data+dec_output[i];
		}
		data = decode_data;

	}
	int datalength = data.length();
	int j = 0;
	for (j=0;j<datalength;){
		if(en_decodetype=="RSA")
			encryptText = encryptText+rsa_pub_encrypt(data.substr(j, ENCRYPT_LENGTH), pub_filename);
		else if(en_decodetype == "ECC")
			encryptText = encryptText+ecc_pub_encrypt(data.substr(j, ENCRYPT_LENGTH), pub_filename);
		j = j+ENCRYPT_LENGTH;
	}
	
	char* enc_output = Base64Encode(encryptText.c_str(), encryptText.length(), false);
	string encode_data = enc_output;
	ofstream fout;
	fout.open(encrypt_filename.c_str(), ios::trunc); 
	if(!fout.is_open()){
		perror("unable to open file!");
		exit(0);
	}
	fout << encode_data; 
	fout.close();
	return 0;
}

