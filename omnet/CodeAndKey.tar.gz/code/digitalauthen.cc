#include <iostream>  
#include <string.h>
#include <fstream> 
#include <openssl/rsa.h>
#include "openssl/pem.h"

// #define KEY_LENGTH  2048               // 密钥长度
// #define SIGN_LENGTH 256
// #define KEY_BYTE 268
int KEY_LENGTH[2]={2048,512};
int SIGN_LENGTH[2]={256,64};
int KEY_BYTE[2]={268,52};
using namespace std;

void sha256(const std::string &srcStr, std::string &encodedStr)
{
	// 调用sha256哈希  
	unsigned char shaStr[33] = {0};
	SHA256((const unsigned char *)srcStr.c_str(), srcStr.length(), shaStr);
 
	// 哈希后的字符串  
	encodedStr = std::string((const char *)shaStr);
}



int rsa_verify(const std::string data, const std::string digitalSign, const std::string pubkey)
{
	unsigned int nSignLen = KEY_LENGTH[0]/8;
	std::string sData;
	// std::cout << pubkey <<endl;
	sha256(data, sData);

	RSA *pubrsa = NULL;
	BIO *pub = BIO_new_mem_buf((unsigned char *)pubkey.c_str(), -1);
	if (pub == NULL){
		perror("unable to generate BIO*!");
		exit(0);
	}

	
	pubrsa = PEM_read_bio_RSAPublicKey(pub, &pubrsa, NULL, NULL);
	
	if (pubrsa == NULL){
		perror("unable to read rsa_pubkey!");
		exit(0);
	}

	int ret = RSA_verify(NID_sha256, (unsigned char *)sData.c_str(), sData.length(), (unsigned char *)digitalSign.c_str(), nSignLen, pubrsa);
	// std::cout << "RSA_verify() ret:" << ret <<endl;

	BIO_free_all(pub);
	RSA_free(pubrsa);


	return ret;
}

int ecc_verify(const std::string data, const std::string digitalSign, const std::string pubkey)
{
	unsigned int nSignLen = KEY_LENGTH[1]/8;
	std::string sData;

	// std::cout << pubkey <<endl;
	sha256(data, sData);
	EC_KEY* pubecc=NULL;
	BIO *pub = BIO_new_mem_buf((unsigned char *)pubkey.c_str(), -1);
	if (pub == NULL){
		perror("unable to generate BIO*!");
		exit(0);
	}

	pubecc = PEM_read_bio_EC_PUBKEY(pub, &pubecc, NULL, NULL);
	// pubrsa = PEM_read_bio_RSAPublicKey(pub, &pubrsa, NULL, NULL);
	
	if (pubecc == NULL){
		perror("unable to read ecc_pubkey!");
		exit(0);
	}

	int ret = ECDSA_verify(NID_sha256, (unsigned char *)sData.c_str(), sData.length(), (unsigned char *)digitalSign.c_str(), nSignLen, pubecc);
	// std::cout << "ECC_verify() ret:" << ret <<endl;

	BIO_free_all(pub);
	EC_KEY_free(pubecc);


	return ret;
}


char * Base64Encode(const char * input, int length, bool with_new_line)
{
	BIO * bmem = NULL;
	BIO * b64 = NULL;
	BUF_MEM * bptr = NULL;
 
	b64 = BIO_new(BIO_f_base64());
	if(!with_new_line) {
		BIO_set_flags(b64, BIO_FLAGS_BASE64_NO_NL);
	}
	bmem = BIO_new(BIO_s_mem());
	b64 = BIO_push(b64, bmem);
	BIO_write(b64, input, length);
	BIO_flush(b64);
	BIO_get_mem_ptr(b64, &bptr);
 
	char * buff = (char *)malloc(bptr->length + 1);
	memcpy(buff, bptr->data, bptr->length);
	buff[bptr->length] = 0;
 
	BIO_free_all(b64);
 
	return buff;
}



char * Base64Decode(char * input, int length, bool with_new_line)
{
	BIO * b64 = NULL;
	BIO * bmem = NULL;
	char * buffer = (char *)malloc(length);
	memset(buffer, 0, length);
 
	b64 = BIO_new(BIO_f_base64());
	if(!with_new_line) {
		BIO_set_flags(b64, BIO_FLAGS_BASE64_NO_NL);
	}
	bmem = BIO_new_mem_buf(input, length);
	bmem = BIO_push(b64, bmem);
	BIO_read(bmem, buffer, length);
 
	BIO_free_all(bmem);
 
	return buffer;
}


int main(int argc, char* argv[])
{
	std::string result_filename = argv[0];
	std::string message = argv[1];
	std::string en_decodetype = argv[2];
	
	char* dec_output = Base64Decode((char *)message.c_str(), message.length(), false);
	int slength = 0;
	while(!((*(dec_output + slength) == NULL) && (*(dec_output + slength + 1) == NULL) \
		&& (*(dec_output + slength + 2) == NULL) && (*(dec_output + slength + 3) == NULL)))
	{
		slength++;
	}
	string decode_sign;
	int i = 0;
	for (i=0;i<slength;i++){
		decode_sign=decode_sign+dec_output[i];
	}
		
	std::string data;
	std::string digitalSign;
	std::string pubkey;
	int flag=0;//使用RSA的密钥长度等信息
	if(en_decodetype=="ECC")flag=1;//使用ECC
	// std::cout << decode_sign.length()<<KEY_BYTE[flag] << std::endl;
	data = decode_sign.substr(0, decode_sign.length()-SIGN_LENGTH[flag]-KEY_BYTE[flag]);
	digitalSign = decode_sign.substr(data.length(), SIGN_LENGTH[flag]);
	pubkey = decode_sign.substr(decode_sign.length()-KEY_BYTE[flag]);
	// std::cout<<"pubkeylength"<<pubkey.length()<<endl;
	char* enc_output = Base64Encode(pubkey.c_str(), pubkey.length(), true);
	pubkey = enc_output;
	
	int ret=0;
	bool temp=en_decodetype=="RSA";
	
	if(en_decodetype=="RSA")
	{
		pubkey = "-----BEGIN RSA PUBLIC KEY-----\n"+pubkey+"-----END RSA PUBLIC KEY-----\n";
		ret = rsa_verify(data, digitalSign, pubkey);
	}
	else if(en_decodetype=="ECC")
	{
		// std::cout << "ecc" << std::endl;
		pubkey = "-----BEGIN PUBLIC KEY-----\n"+pubkey+"-----END PUBLIC KEY-----\n";
		ret = ecc_verify(data, digitalSign, pubkey);
	}
	else
	{
		std:cout<<"error:unknowd algorithm"<<endl;

	}
	ofstream fout;
	fout.open(result_filename.c_str(), ios::trunc); 
	if(!fout.is_open()){
		perror("unable to open file!");
		exit(0);
	}
	std::string data1 = "1"+data;
	std::string data0 = "0"+data;
	fout << ((ret)?data1:data0); 
	fout.close();


	return 0;
}
