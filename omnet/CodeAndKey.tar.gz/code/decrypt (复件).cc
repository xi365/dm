#include <iostream>  
#include <string.h>  
#include "openssl/sha.h"  
#include "openssl/rsa.h"  
#include "openssl/pem.h"
#include <fstream> 

#define KEY_LENGTH  2048	// 密钥长度
#define KEY_BYTE KEY_LENGTH/8

using namespace std;

// 私钥解密
// RSA  
std::string rsa_pri_decrypt(const std::string &cipherText, const std::string &priKey)
{
	std::string strRet;
	BIO* priin = BIO_new(BIO_s_file());
    	if (priin == NULL){
		perror("unable to generate BIO*!");
		exit(0);
	}
    	BIO_read_filename(priin, priKey.c_str());
    	RSA* prirsa = PEM_read_bio_RSAPrivateKey(priin, NULL, NULL, NULL);
	if(prirsa==NULL){
		perror("unable to read rsa_prikey!");
		exit(0);
	}
   	BIO_free(priin);

	int len = RSA_size(prirsa);
	char *decryptedText = (char *)malloc(len + 1);
	memset(decryptedText, 0, len + 1);
 
	// 解密函数
	int ret = RSA_private_decrypt(cipherText.length(), (const unsigned char*)cipherText.c_str(), (unsigned char*)decryptedText, prirsa, RSA_PKCS1_PADDING);
	if (ret >= 0)strRet = std::string(decryptedText, ret);
	// 释放内存
	free(decryptedText);
	RSA_free(prirsa);
 
	return strRet;
}

//ECC
std::string ecc_pri_decrypt(const std::string &cipherText, const std::string &priKey)
{
	std::string strRet;
	int siglen;
	BIO* priin = BIO_new(BIO_s_file());
    	if (priin == NULL){
		perror("unable to generate BIO*!");
		exit(0);
	}
    	BIO_read_filename(priin, priKey.c_str());
    	EC_KEY* priecc = PEM_read_bio_ECPrivateKey(priin, NULL, NULL, NULL);
	if(priecc==NULL){
		perror("unable to read ecc_prikey!");
		exit(0);
	}
   	BIO_free(priin);

	int len = ECDSA_size(priecc);
	char *decryptedText = (char *)malloc(len);
	memset(decryptedText, 0, len);
 
	// 解密函数
	int ret = ECDSA_verify(0, (const unsigned char*)cipherText.c_str(),cipherText.length(), (unsigned char*)decryptedText, 0,priecc);
	if (ret >= 0)strRet = std::string(decryptedText, ret);
	// 释放内存
	free(decryptedText);
	EC_KEY_free(priecc);
 
	return strRet;
}

char * Base64Encode(const char * input, int length, bool with_new_line)
{
	BIO * bmem = NULL;
	BIO * b64 = NULL;
	BUF_MEM * bptr = NULL;
 
	b64 = BIO_new(BIO_f_base64());
	if(!with_new_line) {
		BIO_set_flags(b64, BIO_FLAGS_BASE64_NO_NL);
	}
	bmem = BIO_new(BIO_s_mem());
	b64 = BIO_push(b64, bmem);
	BIO_write(b64, input, length);
	BIO_flush(b64);
	BIO_get_mem_ptr(b64, &bptr);
 
	char * buff = (char *)malloc(bptr->length + 1);
	memcpy(buff, bptr->data, bptr->length);
	buff[bptr->length] = 0;
 
	BIO_free_all(b64);
 
	return buff;
}



char * Base64Decode(char * input, int length, bool with_new_line)
{
	BIO * b64 = NULL;
	BIO * bmem = NULL;
	char * buffer = (char *)malloc(length);
	memset(buffer, 0, length);
 
	b64 = BIO_new(BIO_f_base64());
	if(!with_new_line) {
		BIO_set_flags(b64, BIO_FLAGS_BASE64_NO_NL);
	}
	bmem = BIO_new_mem_buf(input, length);
	bmem = BIO_push(b64, bmem);
	BIO_read(bmem, buffer, length);
 
	BIO_free_all(bmem);
 
	return buffer;
}



int main(int argc, const char *argv[])
{
	std::string encryptData = argv[0];
	std::string pri_filename = argv[1];
	std::string decrypt_filename = argv[2];
	std::string encoded = argv[3];
	std::string en_decodetype = argv[4];
	std::string decryptText="";
	
	char* dec_output = Base64Decode((char *)encryptData.c_str(), encryptData.length(), false);
	int clength = 0;
	while(!((*(dec_output + clength) == NULL) && (*(dec_output + clength + 1) == NULL) \
		&& (*(dec_output + clength + 2) == NULL) && (*(dec_output + clength + 3) == NULL)))
	{
		clength++;
	}
	

	int i = 0;
	std::string decode_data;
	for (i=0;i<clength;i++){
		decode_data=decode_data+dec_output[i];
	}

	int encdata_len = decode_data.length();
	for (i=0;i<encdata_len;){
		if(en_decodetype == "RSA")
		{
			decryptText = decryptText+rsa_pri_decrypt(decode_data.substr(i, KEY_BYTE), pri_filename);
			// std::cout << "rsa: " << std::endl;
		}	
		else{
			decryptText = decryptText+ecc_pri_decrypt(decode_data.substr(i, KEY_BYTE), pri_filename);
			// std::cout << "ECC: " << std::endl;
		}
			
		i = i+KEY_BYTE;
	}
	

	if (strcmp(encoded.c_str(), "true")==0){
		char* enc_output = Base64Encode(decryptText.c_str(), decryptText.length(), false);
		std::string encode_data = enc_output;
		decryptText = encode_data;
	}

	ofstream fout;
	fout.open(decrypt_filename.c_str(), ios::trunc); 
	if(!fout.is_open()){
		perror("unable to open file!");
		exit(0);
	}
	//防止数据为空，添加数据使仿真继续
	if(decryptText.empty())
	{
		decryptText="this is default data";
	}
	fout << decryptText;
	fout.close();

	return 0;
}


